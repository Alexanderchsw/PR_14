package com.example.pr_14_winter;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.media.Image;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TableRow;

public class menu extends AppCompatActivity implements View.OnClickListener{
TableRow tr1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);

        tr1 = findViewById(R.id.tr1);
        tr1.setOnClickListener(this);


    }

    @Override
    public void onClick(View view) {
        Intent intent = new Intent(this, uprazneniy.class);
        startActivity(intent);

    }
}